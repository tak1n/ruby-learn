module RDoc::RI

  Store = RDoc::Store # :nodoc:

end

