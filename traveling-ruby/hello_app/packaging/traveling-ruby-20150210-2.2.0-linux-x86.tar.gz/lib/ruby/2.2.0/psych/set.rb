module Psych
  class Set < ::Hash
  end
end
