# This file was used to load all the RDoc::CodeObject subclasses at once.  Now
# autoload handles this.

require 'rdoc'

